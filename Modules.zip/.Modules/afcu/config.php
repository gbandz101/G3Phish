<?php 
// Define your open Telegram bot token and chat ID
$TelegramBotToken = 'YourBotToken';
$ChatId = 'YourChatID';
?>